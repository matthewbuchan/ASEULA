from django.shortcuts import render
from django.views.generic.edit import FormView
from processing.models import jobData
from .forms import FileFieldForm

# Create your views here.