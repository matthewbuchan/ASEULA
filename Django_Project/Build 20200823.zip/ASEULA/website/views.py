from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
from processing.models import positiveTerm, negativeTerm, restrictionTitle, restrictionTerm,fileStorageData
from processing.processfile import *
from django.conf import settings
from .models import softwareIndex
from .forms import UploadFileForm
import datetime

# Create your views here.
def Home(request):
        all_documents = fileStorageData.objects.all()
        return render(request, 'main.html', {'Documents' : all_documents})

def ImportFile(request):
        form = UploadFileForm()        
        if request.method == "POST":                
                form = UploadFileForm(request.POST, request.FILES)
                if form.is_valid():
                        form.save()
                        return redirect('Home')
        else:
                form = UploadFileForm()
        return render(request, 'importfile.html', {
                'form': form})

def ImportText(request):
        if request.method == 'POST':
                usertext = request.POST.get('document')
                print(usertext)
                tempfile = str("usertxt" + str(datetime.datetime.now().strftime("%Y%m%d%H%M%S")))
                f = open(tempfile+".txt",mode="w+")
                f.write(str(usertext))
                f.close()
                # fs = FileSystemStorage()
                # fs.save(tempfile + "txt", tempfile+".txt")
                return redirect('Home')
        return render(request, 'importtext.html')

def delete_file(request, pk):
        if request.method == 'POST':
                queuedFile = fileStorageData.objects.get(pk=pk)
                queuedFile.delete()
        return redirect('Home')

def ProcessFiles(request):
        posterms = []
        negterms = []
        rxion_dict = {}
        for term in positiveTerm.objects.all():
                posterms.append(term.posterm)
        for term in negativeTerm.objects.all():
                negterms.append(term.negterm)
        for term in restrictionTerm.objects.all():
                if str(term.restriction) in rxion_dict:
                        rxion_dict[str(term.restriction)].append(str(term))
                else:
                        rxion_dict[str(term.restriction)] = []
                        rxion_dict[str(term.restriction)].append(str(term))
        file_list = fileStorageData.objects.all()
        for filename in file_list:                
                #store values from ASEULA Process
                jobData = AseulaMain("media/processing/" + str(filename),posterms,negterms, rxion_dict)
                # print(jobData[0],"\n\n")
                # print(jobData[1],"\n\n")
                # print(jobData[2],"\n\n")
                # print(jobData[3],"\n\n")
                # print(jobData[4],"\n\n")
                # for key in jobData[5]:
                #         print(key)
                #         print(jobData[5][key],"\n\n")
                fileid = fileStorageData.objects.get(pk=filename.pk)
                fileid.delete()
                pass
        
        return render(request,"loading.html", {'file_list':file_list,})

def Software(request):
        all_software = softwareIndex.objects.all()
        return render(request,"software.html",{'Softwares': all_software})