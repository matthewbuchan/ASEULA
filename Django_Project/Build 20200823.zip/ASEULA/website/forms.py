from django import forms
from processing.models import fileStorageData

class UploadFileForm(forms.ModelForm):
    class Meta:
        model = fileStorageData
        fields = ('filefield',)