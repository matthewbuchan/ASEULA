from django.db import models
import os

# Create your models here.
class positiveTerm(models.Model):
    posterm = models.CharField(max_length=20)

    def __str__(self):
        return self.posterm

class negativeTerm(models.Model):
    negterm = models.CharField(max_length=20)

    def __str__(self):
        return self.negterm

class restrictionTitle(models.Model):
    restriction = models.CharField(max_length=30)

    def __str__(self):
        return self.restriction

class restrictionTerm(models.Model):
    restriction = models.ForeignKey('restrictionTitle',on_delete=models.CASCADE)
    restrictionterm = models.CharField(max_length=20)

    def __str__(self):
        return self.restrictionterm

class fileStorageData(models.Model):
    filefield = models.FileField(upload_to='processing/')
    filename = models.CharField(max_length=30)
    softwarename = models.CharField(max_length=30)
    publishername = models.CharField(max_length=50,blank=True, null=True)
    informationpage = models.CharField(max_length=50,blank=True, null=True)
    restrictionlist = models.TextField(blank=True, null=True)
    fulldoctext = models.TextField()

    # def save(self, *args, **kwargs):
    #     self.filename = os.path.basename(self.filefield.name)
    #     super().save(*args, **kwargs)

    def delete(self, *args, **kwargs):
        self.filefield.delete()
        super().delete(*args, **kwargs)

    def get_absolute_url(self):
        return os.path.abspath(self.filename)

    def __str__(self):
        return os.path.basename(self.filefield.name)

class infoFieldName(models.Model):
    fileename = models.ForeignKey('fileStorageData',on_delete=models.CASCADE)
    infoField = models.CharField(max_length=30)

class infoFieldOutput(models.Model):
    filename = models.ForeignKey('fileStorageData', on_delete=models.CASCADE)
    infoField = models.ForeignKey('infoFieldName', on_delete=models.CASCADE)
    infoVar = models.CharField(max_length=30)

class informationPageList(models.Model):
    filename = models.ForeignKey('fileStorageData',on_delete=models.CASCADE)
    infoField = models.ForeignKey('infoFieldName', on_delete=models.CASCADE)
    informationpage = models.CharField(max_length=50)

    def __str__(self):
        return self.filename

class flaggedRestriction(models.Model):
    filename = models.ForeignKey('fileStorageData',on_delete=models.CASCADE)
    restriction = models.CharField(max_length=80)

    def __str__(self):
        return self.filename

class flaggedSentence(models.Model):
    restriction = models.ForeignKey('flaggedRestriction',on_delete=models.CASCADE)
    sentence = models.TextField()

    def __str__(self):
        return self.filename