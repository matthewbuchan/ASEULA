import processfile
rxion_patterns = {}
pos_trigger_words = ["only", "grant", "grants", "granting", "granted", "allow", "allows", "allowing", "allowed", "permit", \
    "permits", "permitting", "permitted", "require", "requires", "requiring", "required", "authorize", "authorizes", \
        "authorizing", "authorized", "necessary"]
neg_trigger_words = ["no", "not", "may not", "not granted", "not allowed", "not permitted", "forbidden", "restricts", "restricted",\
        "prohibits", "prohibited"]
rxion_patterns["Instructional-use only"] = ["teaching", "teaching use", "teaching-use", "instruction", "instructional use",\
        "instructional-use", "instructional purposes", "academic", "academic use", "academic-use", "academic instruction",\
            "academic institution", "academic purposes", "educational", "educational use", "educational-use",\
                "educational instruction", "educational institution", "institution", "educational purposes"]
rxion_patterns["Research-use only"] = ["research", "research use", "research-use"]
rxion_patterns["Requires Physical Device"] = ["activation key", "dongle","hardware"]
rxion_patterns["No RDP use"] = ["remote", "rdp", "remote access", "remote-access", "remote desktop", "remote interface"]
rxion_patterns["Use geographically limited (Campus)"] = ["designated site", "customer's campus", "internally","campus","facility"]
rxion_patterns["Use geographically limited (radius)"] = ["radius", "limited radius", "geographically limited radius",\
        "geographically-limited radius", "particular geography", "site license", "site licenses"]
rxion_patterns["US use only"] = ["united states", "united states use", "u.s.", "u.s. use","export"]
rxion_patterns["VPN required off-site"] = ["vpn", "virtual private network", "remote access"]
rxion_patterns["Block embargoed countries"] = ["embargo", "embargoed", "embargoed country","export","countries"]
rxion_patterns["Block use from Persons of Concern"] = ["person of concern", "persons of concern", "people of concern",\
    "denied persons","person","entity"]
rxion_patterns["On-site (lab) use only"] = ["lab-use"]
rxion_patterns["On-site use for on-site students only"] = ["single fixed geographic site", "fixed geographic site",\
        "geographic site", "on-site", "on-site use"]
rxion_patterns["Virtualization Allowed"] = ["virtualization", "virtualizing", "multiplexing", "pooling"]
filename_array = [] #Filename storage for jobs
rxion_array = []
rxionjob_sentence_array = [] #Temporary pattern matched sentence storage for jobs
jobDataArray = []
i = 0
if len(sys.argv) >= 2:
    for filename in sys.argv[1:]:
        fileArray = []
        filename_array.append(filename.strip('"'))
        i += 1
else:
    print("\nASEULA Alpha Build 200727 for",current_sys)
    fileInput = True
    current_sys = platform.system()
    while fileInput == True:
        inputFile = input("\nPlease enter the absolute path for file or directory you would like to process (or press enter to continue): ").strip('"')
        if inputFile != "":
            if current_sys.lower() == "windows":
                while True:
                    if os.path.isdir(inputFile) == True:
                        filelist = os.listdir(inputFile)
                        for f in filelist:
                            if ".pdf" in str(f) or ".docx" in str(f) or ".txt" in str(f):
                                filename_array.append(str(inputFile) + "\\" + str(f))
                        break
                    elif os.path.isfile(inputFile) == True:
                        filename_array.append(inputFile)
                        break
                    else:
                        print("You did not enter a valid file or directory. Read the directions. ")
            elif current_sys.lower() == "linux":
                while True:
                    if os.path.isdir(inputFile):
                        filelist = os.listdir(inputFile)
                        for line in filelist:
                            filename_array.append(str(inputFile) + line)
                        print(filename_array)
                        break
                    elif os.path.isfile(inputFile):
                        filename_array.append(inputFile)
                        break
                    else:
                        print(inputFile,"You did not enter a valid file or directory. Read the directions. ")
                        break
            else:
                print("Sorry, this script is only compatible with superior operating systems. Get a real computer, jack a**. ")
        else:
            fileInput = False
RunQueue(filename_array, jobDataArray)