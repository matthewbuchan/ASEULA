from django.contrib import admin
from .models import positiveTerm, negativeTerm, restrictionTitle, restrictionTerm, fileStorageData, infoFieldName, infoFieldOutput, informationPageList,flaggedRestriction,flaggedSentence

# Register your models here.
admin.site.register(positiveTerm)
admin.site.register(negativeTerm)
admin.site.register(restrictionTitle)
admin.site.register(restrictionTerm)
admin.site.register(fileStorageData)
admin.site.register(infoFieldName)
admin.site.register(infoFieldOutput)
admin.site.register(informationPageList)
admin.site.register(flaggedRestriction)
admin.site.register(flaggedSentence)