from django.apps import AppConfig


class ProcessingConfig(AppConfig):
    name = 'processing'
