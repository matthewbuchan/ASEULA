from django.db import models

# Create your models here.
class positiveTerm(models.Model):
    posterm = models.CharField(max_length=20)


class negativeTerm(models.Model):
    negterm = models.CharField(max_length=20)


class restrictionTerm(models.Model):
    restrictionterm = models.CharField(max_length=20)

class jobData(models.Model):
    basename = models.CharField(max_length=20)
    documenttext = models.TextField()

class outputSummary(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    softwarename = models.CharField(max_length=20)
    publishername = models.CharField(max_length=50)
    informationpage = models.CharField(max_length=50)
    restrictionlist = models.TextField()

class softwareNameListing(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    softwarename = models.CharField(max_length=20)

class publisherNameListing(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    publisher = models.CharField(max_length=50)

class informationPageListing(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    informationpage = models.CharField(max_length=50)

class flaggedRestriction(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    restriction = models.CharField(max_length=80)

class flaggedSentence(models.Model):
    restriction = models.ForeignKey('flaggedRestriction',on_delete=models.CASCADE)
    sentence = models.TextField()    

class storedDoc(models.Model):
    basename = models.ForeignKey('jobData',on_delete=models.CASCADE)
    documenttext = models.TextField()
