from django.contrib import admin
from .models import positiveTerm, negativeTerm, restrictionTerm, jobData, outputSummary, softwareNameListing, publisherNameListing,informationPageListing,flaggedRestriction,flaggedSentence,storedDoc

# Register your models here.
admin.site.register(positiveTerm)
admin.site.register(negativeTerm)
admin.site.register(restrictionTerm)
admin.site.register(jobData)
admin.site.register(outputSummary)
admin.site.register(softwareNameListing)
admin.site.register(publisherNameListing)
admin.site.register(informationPageListing)
admin.site.register(flaggedRestriction)
admin.site.register(flaggedSentence)
admin.site.register(storedDoc)