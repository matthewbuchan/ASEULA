from django.shortcuts import render
from django.shortcuts import HttpResponse
from .models import softwareIndex

# Create your views here.

def Home(request):
        return render(request, 'main.html')

def Software(request):
        all_software = softwareIndex.objects.all()
        return render(request,"software.html",{'Softwares': all_software})
