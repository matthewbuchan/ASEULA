from django.db import models

# Create your models here.
class softwareIndex(models.Model):
    softwarename = models.CharField(max_length=30)
    version = models.CharField(max_length=20)
    publishername = models.CharField(max_length=30)
    informationurl = models.CharField(max_length=50)
    flaggedrestrictions = models.TextField()
    storeddocument = models.TextField()
    checkdate = models.DateTimeField()
    checkby = models.CharField(max_length=50)
    licensetype = models.CharField(max_length=30)
    licensecount = models.IntegerField()
    